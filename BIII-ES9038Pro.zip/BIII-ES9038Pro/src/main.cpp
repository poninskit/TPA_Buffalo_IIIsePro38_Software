//******************************************************************************
// ES 9038 Pro, Version 1.0
// Poninski Tomasz, 2019-05-05
//******************************************************************************
//Arduino enviroment
#include <Arduino.h>
//Header for global declarations
#include <globals.h>
//header for all DAC classes
#include <dac.h>
#include <interfaces.h>
#include <tftgraphics.h>

//------------------------------------------------------------------------------
#define READ_DAC_CYCLES   10
//------------------------------------------------------------------------------
// classes declarations

// DAC and EEPROM classes
DAC* dac;
//REMOTE CONTROLL
RemoteInterface* remoteInterface;
//TOUCH INTERFACE
TouchInterface* touchInterface;
//TFT SCREEN
TFTGraphics* tftGraphics;


//------------------------------------------------------------------------------
//Variables
ACTION action;
int read_dac_counter;

//------------------------------------------------------------------------------


//******************************************************************************
// SETUP DAC
//******************************************************************************
void setup() {

  //Serial port for debugging
  if(DEBUG) Serial.begin(9600);
  LOG("Debug mode\n");

  //initilize classes
   dac = new DAC(); // Constructor powers up, sets the DAC I2C and default settings
   remoteInterface = new RemoteInterface();
   touchInterface = new TouchInterface();
   tftGraphics = new TFTGraphics();

   //display initial values
   tftGraphics->printChannel( dac->getInput() );
   tftGraphics->printVolume( dac->getVolume() );

   //init variables
   action = NONE;
   read_dac_counter = 0;

}


//******************************************************************************
// LOOP THE DAC COMMANDS
//******************************************************************************
void loop() {

  //USER INPUT
  //get action from remote controller
  action = remoteInterface->getAction();
  //if no action from remote controller read the touch interface
  if( action == NONE )
    action = touchInterface->getAction( MAIN_MENU );


  //No Action taken
  //Update DAC lock status after given amount of cycles
  if( action == NONE && read_dac_counter >= READ_DAC_CYCLES){
    read_dac_counter = 0;
    //read switches, lock, sample rete
    dac->readSwitchStates();
    tftGraphics->printInfoText( dacLockString( dac->getLockStatus() ) );
  }


  //TAKE ACTION
  switch ( action ){
    case NONE:
      break;
    case CHANNEL_LEFT:
      tftGraphics->printChannel( dac->decreaseInput() );
      break;
    case CHANNEL_RIGHT:
      tftGraphics->printChannel( dac->increaseInput() );
      break;
    case VOLUME_UP:
      tftGraphics->printVolume( dac->increaseVolume() );
      break;
    case VOLUME_DOWN:
      tftGraphics->printVolume( dac->decreaseVolume() );
      break;
    case ENTER:
      tftGraphics->printVolume( dac->muteVolume() );
      break;
    case MENU:
      //Optional DAC Settings
      break;
    case CONTROL:
      //OPTIONAL
      break;
    case RESET:
      //OPTIONAL
      break;
  }
  //After taking action reset the flag
  action = NONE;
  //increment var to update DAC connection status
  read_dac_counter++;

}
//******************************************************************************
