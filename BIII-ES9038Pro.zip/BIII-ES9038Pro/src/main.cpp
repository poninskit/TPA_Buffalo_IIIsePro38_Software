//******************************************************************************
// ES 9038 Pro, Version 1.0
// Poninski Tomasz, 2019-05-05
//******************************************************************************
//Arduino enviroment
#include <Arduino.h>
//Header for global declarations
#include "globals.h"
//header for all DAC classes
#include <dac.h>
#include <interfaces.h>
#include <tftgraphics.h>

//------------------------------------------------------------------------------
#define READ_DAC_CYCLES   10
//------------------------------------------------------------------------------
// classes declarations

// DAC and EEPROM classes
DAC* dac;
//REMOTE CONTROLL
RemoteInterface* remoteInterface;
//TOUCH INTERFACE
TouchInterface* touchInterface;
//TFT SCREEN
TFTGraphics* tftGraphics;


//------------------------------------------------------------------------------
//Variables
ACTION action = NONE;
ACTION lastAction = NONE;
int read_dac_counter = 0;

//differentiate interfaces apply specific delay
INTERFACE interface = NONE_IFC;
//use delay if necessary to give user respond time
int delay_ms = 0;
//delay values
int delay_hold = 15;
int delay_switch = 400;


//detect button hold
int act_after = 500;
int wait_after_act = act_after + 300;
bool hold_tapped_only = false;

unsigned long pressTime = 0;
unsigned long lastInterruptTime = 0;


//******************************************************************************
// SETUP DAC
//******************************************************************************
void setup() {

  //Serial port for debugging
  if(DEBUG) Serial.begin(9600);
  LOG("Debug mode\n");

  //initilize classes
   dac = new DAC(); // Constructor powers up, sets the DAC I2C and default settings
   remoteInterface = new RemoteInterface();
   touchInterface = new TouchInterface();
   tftGraphics = new TFTGraphics();

   //display initial values
   tftGraphics->printChannel( dac->getInput() );
   tftGraphics->printVolume( dac->getVolume() );

}


//******************************************************************************
// LOOP THE DAC COMMANDS
//******************************************************************************
void loop() {


  //get action from remote controller
  action = remoteInterface->getAction();
  //if no action from remote controller read the touch interface
  if( action != NONE ){
    interface = REMOTE; 
  }else{
    action = touchInterface->getAction( MAIN_MENU );
    if (action != NONE) interface = TOUCH;
  }

  //No Action taken, update DAC lock status after given amount of cycles
  if( action == NONE && read_dac_counter >= READ_DAC_CYCLES){
    read_dac_counter = 0;
    //read switches, lock, sample rete
    dac->readSwitchStates();
    tftGraphics->printInfoText( dac->dacLockString( dac->getLockStatus() ) );
  }


  //TAKE ACTION
  switch ( action ){
    case NONE:
      break;
    case CHANNEL_LEFT:
      tftGraphics->printChannel( dac->decreaseInput() );
      if(interface == TOUCH) delay_ms = delay_switch;
      break;
    case CHANNEL_RIGHT:
      tftGraphics->printChannel( dac->increaseInput() );
      if(interface == TOUCH) delay_ms = delay_switch;
      break;
    case VOLUME_UP:
      tftGraphics->printVolume( dac->increaseVolume() );
      if(interface == TOUCH) delay_ms = delay_hold;
      break;
    case VOLUME_DOWN:
      tftGraphics->printVolume( dac->decreaseVolume() );
      if(interface == TOUCH) delay_ms = delay_hold;
      break;
    case ENTER:
      tftGraphics->printVolume( dac->muteVolume() );
      if(interface == TOUCH) delay_ms = delay_switch;
      break;
    case POWER_ON:{
        int interval = millis() - pressTime;
        if( lastAction != POWER_ON || interval > wait_after_act ){ //interval wait to start new holding
          pressTime = lastInterruptTime = millis();
          LOG("----------first touch----------");
        }else{ //  hold
          //First holding
          int no_touch = millis() - lastInterruptTime;
          if( no_touch > 200 ){ //reset as holding interrupt detected
            action = RESET; //this will set all new
            pressTime = lastInterruptTime = millis();
            LOG("Interruption, start new counter (reset)");
            break;
          }else{
            lastInterruptTime = millis(); //update interrupt time
          }
          interval = millis() - pressTime;
          LOG( interval );
          if( interval > act_after ){ // holding
          /*
          This is where the touch screen hold action should be placed
          */
          //dac->power_on();
          LOG("Power on / off")
          pressTime = millis(); //update press time
        }else if ( interval < 300 ){
          hold_tapped_only = true;
        }
      }
      }break;
    default:
      break;
  }

    
  //response delay if set
  if ( delay_ms ) delay ( delay_ms );


  //remember last action
  lastAction = action;
  //After taking action reset the flag
  action = NONE;
  //reset interface
  interface = NONE_IFC;
  //increment var to update DAC connection status
  read_dac_counter++;
  //reset delay
  delay_ms = 0;
  
}
//******************************************************************************
