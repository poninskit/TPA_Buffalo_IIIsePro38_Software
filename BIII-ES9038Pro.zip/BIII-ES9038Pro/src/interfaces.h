#ifndef INTERFACES_H
#define INTERFACES_H

//==============================================================================
#include <globals.h>
#include <IRremote2.h> // Remote
#include <URTouch.h> // For Touchscreen

//==============================================================================
//==============================================================================
class RemoteInterface:IRrecv{
  public:
    RemoteInterface( int recvpin = 8 );
    ACTION getAction( );

  private:
    decode_results results;

    ACTION action;  // actual action
    ACTION prevAct; // last action taken for repeat
};

//==============================================================================
//==============================================================================
class TouchInterface:URTouch{
  public:
    TouchInterface(byte tclk = 6, byte tcs = 5, byte tdin = 4, byte dout = 3, byte irq = 2);
    ACTION getAction( PAGE page );

  private:
    ACTION action;
    int x;
    int y;

    ACTION actionFromMAIN( int x, int y );
    ACTION actionFromSETTINGS( int x, int y );
};
//==============================================================================
//==============================================================================
#endif /* INTERFACES_H */
