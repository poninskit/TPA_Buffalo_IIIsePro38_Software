#include <interfaces.h>

//==============================================================================
//==============================================================================
RemoteInterface::RemoteInterface(int recvpin)
                :IRrecv(recvpin)
{
    enableIRIn(); // Start the IR receiver
    prevAct = NONE;
}

//------------------------------------------------------------------------------
ACTION RemoteInterface::getAction(){
/*
The Apple remote returns the following codes:
The value for the third byte when we discard the least significant bit is:
    HEX:
    Repaet -   FFFFFFFF / 4294967295
    UP -       77E1D06C / 2011287660
    Down -     77E1B06C / 2011279468
    Right -    77E1E06C / 2011291756
    left -     77E1106C / 2011238508
    middle -   77E1BA6C or 77E1206C / 2011282028 or 2011242604
    menue -    77E1406C / 2011250796
    play -     77E17A6C or 77E1206C / 2011265644 or 2011242604
*/

  if ( !decode( &results ) )
    return NONE;


   LOG( "Remote:" + String( results.value ) );

    switch (results.value){
      case 4294967295: // REPEAT
        //reapeat if volume change, holding the vol button
        if ( prevAct == VOLUME_DOWN || prevAct == VOLUME_UP ){
          action = prevAct;
        }else{
          action = NONE;
        }
      break;
      case 2011287696: // UP
      case 2011255020:
        action = VOLUME_UP;
      break;
      case 2011279504: // DOWN
      case 2011246828 :
        action = VOLUME_DOWN;
      break;
      case 2011291792: // RIGHT
      case 2011259116:
        action = CHANNEL_RIGHT;
      break;
      case 2011238544: // LEFT
      case 2011271404:
        action = CHANNEL_LEFT;
      break;
      case 2011282064: // MIDDLE  or 77E1206C
      case 2011275500:
        action = ENTER;
      break;
      case 2011250832:  // MENU
      case 2011283692:
        action = MENU;
      break;
      case 2011265680: // PLAY or 77E1206C
      case 2011265644:
        action = CONTROL;
      break;
      default:
        action = NONE;
      break;
      }

    LOG("Remote action: " + String(action) );

    resume();
    prevAct = action;    // Remember the key in case we want to use the repeat code

return action;
}



//==============================================================================
//==============================================================================
TouchInterface::TouchInterface(byte tclk, byte tcs, byte tdin, byte dout, byte irq)
               :UTouch(tclk, tcs, tdin, dout, irq)
{

  InitTouch();
  setPrecision(PREC_MEDIUM);

  x = 0;
  y = 0;

}

//------------------------------------------------------------------------------
ACTION TouchInterface::getAction( PAGE page ){

  if (!dataAvailable())
    return NONE;

       read();
       x = getX();
       y = getY();

if (page == MAIN_MENU){
  return actionFromMAIN( x, y);
}else if(page == SETTINGS_MENU){
  return actionFromSETTINGS( x, y );
}


return NONE;
}
//------------------------------------------------------------------------------
ACTION TouchInterface::actionFromMAIN( int x, int y ){


  if ((x>=5) && (x<=145)){  // Left column

      if ((y>=10) && (y<=45)){  // Button: Input
        action = CHANNEL_RIGHT;
      }
      if ((y>=130) && (y<=165)){  // Button: Vol up
        action = VOLUME_UP;
      }
      if ((y>=180) && (y<=215)){  // Button: Vol down
        action = VOLUME_DOWN;
      }

  }else if ((x>=220) && (x<=340)){

      if ((y>=10) && (y<=45)){  // Button: SETTINGS / EXIT            {
        action = MENU;
      }
      if ((y>=130) && (y<=235)){  // Button: Mute
        action = ENTER;
      }

  }

return action;
}
//------------------------------------------------------------------------------
ACTION TouchInterface::actionFromSETTINGS( int x, int y ){
  return NONE;
}
//==============================================================================
//==============================================================================
