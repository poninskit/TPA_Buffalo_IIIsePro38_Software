#ifndef GLOBALS_H
#define GLOBALS_H
//------------------------------------------------------------------------------
//ENUMERATORS

//------------------------------------------------------------------------------
#define DEBUG 0

#if DEBUG == 1
  #define LOG(s) Serial.print(s)
#else
  #define LOG(s)
#endif

enum DAC_INPUT{
  USB = 0,
  OPT1,
  OPT2,
  SPDIF
};

//Action
enum ACTION{
  NONE = 0,
  CHANNEL_LEFT,
  CHANNEL_RIGHT,
  VOLUME_UP,
  VOLUME_DOWN,
  ENTER,
  MENU,
  CONTROL,
  RESET
};

//MENU PAGES
enum PAGE{
  MAIN_MENU,
  SETTINGS_MENU,
};


//------------------------------------------------------------------------------
#endif // GLOBALS_H
