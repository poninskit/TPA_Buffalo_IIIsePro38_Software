
#include <dac.h>
#include <Wire.h>  // For I2C
#include <ES9028_38.h> //Buffalo config file


//==============================================================================
//==============================================================================
DAC::DAC()
{
    //Power DAC  UP
    powerDACup();
    //Initialize DAC Register setting
    initializeDAC();
    //config DAC
    configureDAC();
    //set initial volume
    setVolume( dac_volume );
    setInput( input );
}



// Returns a text description of an ErrorCode
// keep at 28 characters
char* DAC::dacLockString(LOCK_STATUS lock)
{
    switch (lock)
    {
    case Unknown:     return (char*)("unknown");
    case Locked:      return (char*)("Locked");
    case No_Lock:     return (char*)("Unlocked");
    default:          return (char*)("");
    }
}

// Returns a text description of an ErrorCode
// keep at 28 characters
char* DAC::dacErrorString(ERROR_CODE code)
{
    switch (code)
    {
    case No_Error:            return (char*)("No error.");
    case Wire_Trans_Error:    return (char*)("Wire begin error.");
    case Volume_Out_Of_Scope: return (char*)("Volume reached max/min.");
    default:                  return (char*)("Unknown Error.");
    }
}

//------------------------------------------------------------------------------
void DAC::powerDACup(){

  //Set Relays for output
  pinMode(RELAY_PIN_1, OUTPUT);
  pinMode(RELAY_PIN_2, OUTPUT);
  pinMode(RESET_PIN, OUTPUT);
  pinMode(MUX_PIN_S0, OUTPUT);
  pinMode(MUX_PIN_S1, OUTPUT);

  // keep DAC in reset
  digitalWrite(RESET_PIN,  LOW);

  // Start DAC, put Relays on High
  digitalWrite(RELAY_PIN_1, HIGH);
  digitalWrite(RELAY_PIN_2, HIGH);
  //wait in reset for 1 sec
  delay(1000);
  // bring DAC out of reset
  digitalWrite(RESET_PIN, HIGH);


}
//------------------------------------------------------------------------------
ERROR_CODE DAC::initializeDAC(){

  //start I2C bus
  Wire.begin();
  delay(1);
  if(!Wire.available() ){
    LOG ( dacErrorString( Wire_Trans_Error ) );
  }

	// configure the port expander
	writeRegister(PE_ADDRESS, PE_IOCONN, 0b00100000);	// we will only be sending one byte at a time
	delay(1);
	writeRegister(PE_ADDRESS, PE_GPPUA, 0b11111111); // enable all weak pull-ups
	writeRegister(PE_ADDRESS, PE_GPPUB, 0b11111111); // enable all weak pull-ups
	delay(10);
	// GET the initial state for the DAC registers
	readSwitchStates();

return No_Error;
}

//------------------------------------------------------------------------------
// read the port expander switch states
void DAC::readSwitchStates() {
	uint8_t s1 = readRegister(PE_ADDRESS, PE_GPIOA);
	uint8_t s2 = readRegister(PE_ADDRESS, PE_GPIOB);
	if (s1 != sw1.byte || s2 != sw2.byte) {
		sw1.byte = s1;
		sw2.byte = s2;
		configureDAC();
	}
}

//------------------------------------------------------------------------------
ERROR_CODE DAC::configureDAC(){

  // configurable stuff:

    //Input from software! uncomment to get input from switch!
  	// R1_INPUT_SELECTION r1;
  	// r1.byte = R1_DEFAULT;
  	// if (sw1.input_mode == INPUT_MODE_SERIAL) {
  	// 	r1.auto_select = R1_AUTO_SELECT_DSD_SERIAL;
  	// 	r1.input_select = R1_INPUT_SELECT_SERIAL;
  	// } else {
  	// 	r1.auto_select = R1_AUTO_SELECT_DISABLE;
  	// 	r1.input_select = R1_INPUT_SELECT_SPDIF;
  	// }
  	// writeRegister(DAC_ADDRESS, 1, r1.byte);



    R2_SERIAL_DATA_AUTOMUTE_CONFIG r2;
  	r2.byte = R2_DEFAULT;
  	if (sw2.automute_enable) r2.automute_config = R2_AUTOMUTE_CONFIG_MUTE;
    switch(sw1.serial_format) {
  		case 0 :
  			r2.serial_mode = R2_SERIAL_MODE_I2S;
  			break;
  		case 1 :
  			r2.serial_mode = R2_SERIAL_MODE_LJ;
  			break;
  		case 2 :
  			r2.serial_mode = R2_SERIAL_MODE_I2S;
  			break;
  		default :
  			r2.serial_mode = R2_SERIAL_MODE_RJ;
  	}

  	switch(sw1.serial_length) {
  		case 0:
  			r2.serial_length = R2_SERIAL_LENGTH_32;
  			r2.serial_bits = R2_SERIAL_BITS_32;
  			break;
  		case 1:
  			r2.serial_length = R2_SERIAL_LENGTH_24;
  			r2.serial_bits = R2_SERIAL_BITS_24;
  			break;
  		case 2:
  			r2.serial_length = R2_SERIAL_LENGTH_16;
  			r2.serial_bits = R2_SERIAL_BITS_16;
  			break;
  		default:
  			r2.serial_length = R2_SERIAL_LENGTH_32;
  			r2.serial_bits = R2_SERIAL_BITS_32;
  	}
  	writeRegister(DAC_ADDRESS, 2, r2.byte);

  	R4_AUTOMUTE_TIME r4;
  	r4.byte = R4_DEFAULT;
  	if (sw2.automute_enable) r4.automute_time = 4;
  	writeRegister(DAC_ADDRESS, 4, r4.byte);

  	R7_FILTER_BW_SYSTEM_MUTE r7;
  	r7.byte = R7_DEFAULT;
  	r7.filter_shape = sw1.filter;
  	r7.iir_bw = sw2.iir_bw;
  	writeRegister(DAC_ADDRESS, 7, r7.byte);

  	R8_GPIO_1_2_CONFIG r8;
  	r8.byte = R8_DEFAULT;
  	r8.gpio1_cfg = GPIO_OUT_AUTOMUTE_STATUS;
  	r8.gpio2_cfg = GPIO_IN_STANDARD_INPUT;
  	writeRegister(DAC_ADDRESS, 8, r8.byte);

  	R9_GPIO_3_4_CONFIG r9;
  	r9.byte = R9_DEFAULT;
  	r9.gpio3_cfg = GPIO_IN_STANDARD_INPUT;
  	r9.gpio4_cfg = GPIO_OUT_LOCK_STATUS;
  	writeRegister(DAC_ADDRESS, 9, r9.byte);

  	R11_SPDIF_MUX_GPIO_INVERT r11;
  	r11.byte = R11_DEFAULT;
  	r11.spdif_sel = 3;
  	writeRegister(DAC_ADDRESS, 11, r11.byte);

  	R12_JE_DPLL_BW r12;
  	uint8_t dpll = sw2.dpll;
  	// we don't ever want the DPLL to be off
  	if (dpll == 0) dpll = 5;
  	r12.byte = R12_DEFAULT;
  	r12.dpll_bw_serial = dpll;
  	r12.dpll_bw_dsd = dpll;
  	writeRegister(DAC_ADDRESS, 12, r12.byte);

  	R13_JE_THD_COMP_CONFIG r13;
  	r13.byte = R13_DEFAULT;
  	writeRegister(DAC_ADDRESS, 13, r13.byte);

  	R15_GPIO_INPUT_SEL_VOLUME_CONFIG r15;
  	r15.byte = R15_DEFAULT;
  	r15.stereo_mode = R15_STEREO_MODE_ENABLED;
  	r15.use_only_ch1_vol = R15_USE_ONLY_CH1_VOLUME_ENABLED;
  	r15.latch_vol = R15_LATCH_VOLUME_ENABLED;
  	writeRegister(DAC_ADDRESS, 15, r15.byte);

  	R37_PROGRAMMABLE_FIR_CONFIG r37;
  	r37.byte = R37_DEFAULT;
  	if (sw2.osf_bypass) {
  		r37.bypass_osf = R37_OSF_DISABLED;
  	} else {
  		r37.bypass_osf = R37_OSF_ENABLED;
  	}
  	writeRegister(DAC_ADDRESS, 37, r37.byte);


return No_Error;
}

//------------------------------------------------------------------------------
byte DAC::getVolume(){
  return dac_volume;
}
//------------------------------------------------------------------------------
DAC_INPUT DAC::getInput(){
  return input;
}
//------------------------------------------------------------------------------
LOCK_STATUS DAC::getLockStatus(){

  LOG ( dacLockString( LOCK_STATUS::Unknown ));
  
  return LOCK_STATUS::Unknown;
}
//------------------------------------------------------------------------------
DAC_INPUT DAC::increaseInput(){
  switch( input ){
    case USB:   input = OPT1;  break;
    case OPT1:  input = OPT2;  break;
    case OPT2:  input = SPDIF; break;
    case SPDIF: input = USB;   break;
  }
  setInput( input );

return input;
}

//------------------------------------------------------------------------------
DAC_INPUT DAC::decreaseInput(){

  switch( input ){
    case USB:   input = SPDIF; break;
    case OPT1:  input = USB;   break;
    case OPT2:  input = OPT1;  break;
    case SPDIF: input = OPT2;  break;
  }
  setInput( input );

  return input;
}
//------------------------------------------------------------------------------
ERROR_CODE DAC::setInput( DAC_INPUT input ){
  /*
  //Settings for input switch
  * A=B1 -> S0=LOW,  S1=LOW  (MUX_PIN_S0 = HIGH, MUX_PIN_S1 = HIGH), TOS1
  * A=B2 -> S0=HIGH, S1=LOW  (MUX_PIN_S0 = LOW,  MUX_PIN_S1 = HIGH), TOS2
  * A=B3 -> S0=LOW,  S1=HIGH (MUX_PIN_S0 = HIGH, MUX_PIN_S1 = LOW),  SPDIF
  * A=B4 -> S0=HIGH, S1=HIGH (MUX_PIN_S0 = LOW,  MUX_PIN_S1 = LOW),
  */

  R1_INPUT_SELECTION r1;
  r1.byte = R1_DEFAULT;

  switch( input ){
    case USB:
        //MUX S0=HIGH, S1=HIGH -> B4, NONE
        digitalWrite(MUX_PIN_S0, LOW);
        digitalWrite(MUX_PIN_S1, LOW);
        //DAC input settings
        r1.auto_select = R1_AUTO_SELECT_DSD_SERIAL;
        r1.input_select = R1_INPUT_SELECT_SERIAL;
      break;
    case OPT1:
        //MUX S0=LOW, S1=LOW -> B1, TOS1
        digitalWrite(MUX_PIN_S0, HIGH);
        digitalWrite(MUX_PIN_S1, HIGH);
        //DAC input settings
        r1.auto_select = R1_AUTO_SELECT_DISABLE;
        r1.input_select = R1_INPUT_SELECT_SPDIF;
      break;
    case OPT2:
        //MUX S0=HIGH, S1=LOW -> B2, TOS2
        digitalWrite(MUX_PIN_S0, LOW);
        digitalWrite(MUX_PIN_S1, HIGH);
        //DAC input settings
        r1.auto_select = R1_AUTO_SELECT_DISABLE;
        r1.input_select = R1_INPUT_SELECT_SPDIF;
      break;
    case SPDIF:
        //MUX S0=LOW, S1=HIGH -> B3, SPDIF
        digitalWrite(MUX_PIN_S0, HIGH);
        digitalWrite(MUX_PIN_S1, LOW);
        //DAC input settings
        r1.auto_select = R1_AUTO_SELECT_DISABLE;
        r1.input_select = R1_INPUT_SELECT_SPDIF;
      break;
  }

  writeRegister(DAC_ADDRESS, 1, r1.byte);


return No_Error;
}

//------------------------------------------------------------------------------
uint8_t DAC::increaseVolume(){

  uint8_t vol = dac_volume;

  if (vol < MAX_VOL)              // Check if not already at maximum attenuation
  {
    if(dimmed) {
    setVolume(vol);
    dimmed = false;
    }
  vol += 1;                 // Increase 1 dB attenuation (decrease dac_volume 1 db)
  setVolume( vol );         // Write value into registers
  }


return dac_volume;
}

//------------------------------------------------------------------------------
uint8_t DAC::decreaseVolume(){

  uint8_t vol = dac_volume;
  if ( vol > MIN_VOL )                // Check if not already at minimum attenuation
  {
      if( dimmed )
      {
      setVolume( vol );
      dimmed = false;
      }

    vol -= 1;     // Decrease attenuation 1 dB
    setVolume( vol );  // try to set dac_volume, if set correctly dac::dac_volume will be changed
  }

return dac_volume;
}


//------------------------------------------------------------------------------
byte DAC::muteVolume(){

uint8_t vol = dac_volume;

    if( dimmed ){                // Back to previous dac_volume level 1 db at a time
      setVolume( vol );          // Write value into registers
      dimmed = false;
    } else {
      if( vol > MUTE_VOL ) {            // only DIM if current attenuation is lower
        setVolume( MUTE_VOL );          // Write value into registers
        dimmed = true;
        byte retVol = dac_volume;       //save actual mute volume
        dac_volume = vol;               //set dac volume to last value, for restoring
        return retVol;                  //return mute volume
      }
    }

return dac_volume;
}

//------------------------------------------------------------------------------
ERROR_CODE DAC::setVolume( uint8_t vol ){

if( vol < MIN_VOL || vol > MAX_VOL ){
  LOG ( dacErrorString( Volume_Out_Of_Scope ) );
  return Volume_Out_Of_Scope;
}

  uint8_t vol_dB = 99 - vol; //possible 0 to -127dB , vol (0-99) 0 MAX, 255 min
  vol_dB = vol_dB * 2;      //increase scale from 0 - 198, step x2, 0,5dB x 2 = 1dB
  //write volume byte to register 16
  writeRegister( DAC_ADDRESS, 16, vol_dB );
  dac_volume = vol;

return No_Error; //readRegister(16);
}

//------------------------------------------------------------------------------
ERROR_CODE DAC::writeRegister( int device, byte regAddr, byte dataVal){
  //for device address get DAC adress
  Wire.beginTransmission( device ); // device
  Wire.write(regAddr); // register
  Wire.write(dataVal); // data
  Wire.endTransmission();

return No_Error;
}

//------------------------------------------------------------------------------
byte DAC::readRegister( int device, byte regAddr ) {

  Wire.beginTransmission( device ); // Hard coded the Sabre/Buffalo device  address
  Wire.write(regAddr);          // Queues the address of the register
  Wire.endTransmission();       // Sends the address of the register
  Wire.requestFrom( device, 1);     // Hard coded to Buffalo, request one byte from address
                                // specified with Wire.write()/wire.endTransmission()
  //while(!Wire.available()) {  // Wait for byte to be available on the bus
  if( !Wire.available() ){          // Wire.available indicates if data is available
    return 0;
  }


return  Wire.read();                   //  return byte
}

//==============================================================================
//  eeprom = new EEPROM();     // myEEPROM object, 256kbit, 1 device on the bus, 64 bytes page size, 0x50
//==============================================================================
EEPROM::EEPROM(eeprom_size_t deviceCapacity, byte nDevice, unsigned int pageSize, byte eepromAddr)
       :extEEPROM(deviceCapacity, nDevice, pageSize, eepromAddr)
{

    if ( begin( twiClock100kHz ) != 0 )
    {
      LOG("Problem with EEPROM communication.");
    }

}
//------------------------------------------------------------------------------
void EEPROM::saveAll(){

}//------------------------------------------------------------------------------
void EEPROM::readAll(){

}
//------------------------------------------------------------------------------
