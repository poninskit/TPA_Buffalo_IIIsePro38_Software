#include <TFTGraphics.h>

//------------------------------------------------------------------------------
TFTGraphics::TFTGraphics(byte model, int RS, int WR, int CS, int RST, int SER)
            :UTFT(model, RS, WR, CS, RST, SER)
{
  InitLCD(LANDSCAPE);
  clrScr();
  printMainButtons();
}


//------------------------------------------------------------------------------
void TFTGraphics::printMainButtons()
{
  drawBitmap(30,180, 74, 74, vdown);
  drawBitmap(150,180, 74, 74, vup);
  drawBitmap(390,20, 74, 74, power);
  //drawBitmap(285,20, 74, 74, set);
  //drawBitmap(255,150, 42, 34, mute);
}


//------------------------------------------------------------------------------
void TFTGraphics::printVolume( uint8_t volume )
{

  int x = 294;
  int y = 134;
  int n = 80; //font space

  setFont( arial_numbers_80x120 );
  setColor(10, 130,40);


   if ( volume  < 10 ){
     print( (char *)"0", x, y );
     print( String( volume ), x + n, y);
   }else{
     print( String( volume ), x, y);
   }


}

//------------------------------------------------------------------------------
void TFTGraphics::printChannel( DAC_INPUT input_id )
{

  switch ( input_id ){
  case USB:
    drawBitmap(25,20, 204, 74, usb);
    break;
  case SPDIF:
    drawBitmap(25,20, 204, 74, spdif);
    break;
  case OPT1:
    drawBitmap(25,20, 204, 74, opt1);
    break;
  case OPT2:
    drawBitmap(25,20, 204, 74, opt2);
    break;
  default:
    break;
  }

}
//------------------------------------------------------------------------------
void TFTGraphics::printInfoText( char* text )
{
  setFont(arial_bold);
  setColor(200, 200, 200);
  int x = 35;
  int y = 110;

  print(text, x, y);
}

//------------------------------------------------------------------------------
void TFTGraphics::clearInfoText()
{
  printInfoText( (char*)clearInfoString );
}
//------------------------------------------------------------------------------
